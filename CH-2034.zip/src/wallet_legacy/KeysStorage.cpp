#include "KeysStorage.h"

#include "WalletLegacySerialization.h"
#include "ISerializer.h"
#include "Serialization/SerializationOverloads.h"
#include "base/CryptoNoteSerialization.h"

namespace CryptoNote {

void KeysStorage::serialize(ISerializer& serializer, const std::string& name) {
  serializer.beginObject(name);

  serializer(creationTimestamp, "creation_timestamp");

  serializer(spendPublicKey, "spend_public_key");
  serializer(spendSecretKey, "spend_secret_key");

  serializer(viewPublicKey, "view_public_key");
  serializer(viewSecretKey, "view_secret_key");

  serializer.endObject();
}

}
