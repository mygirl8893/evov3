// Copyright (c) 2012-2018
/* 
==================Core Developer==================
The CryptoNote Developer
The Bytecoin Developer
The Monero Developer
The Sumo Developer
The Kabowanec Developer
The XDN Developer
The Royalties Developer
==================Add On Developer================
[ ] developers
- Sora as Core Platform
- Shiro as Compiler and Bug Solver
- Homdx as Docker Engineer
- James as GUI Specialist
=================External Developer===============
- Aiwe K as CN-7 impelemented algorithm
====================Algorithm=====================
Brian Gladman, Worcester, UK.[aesb]
http://131002.net/blake/[blake]
HAMC[blake]
D. J. Bernstein[chacha]
Thomas Krinninger[groestl]
Soeren S. Thomsen and Krystian Matusiewicz[groestl]
Nabil S. Al Ramli, www.nalramli.com[openaes]
Markku-Juhani O. Saarinen <mjos@iki.fi>[keccak]
Doug Whiting, 2008[skein]
=================Platform Developer===============
Christopher M. Kohlhoff (chris at kohlhoff dot com)
====================Support=======================
Shaik Vahid original support for Nur1Labs




you can added manual
*/
