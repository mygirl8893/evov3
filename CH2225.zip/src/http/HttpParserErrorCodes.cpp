#include "HttpParserErrorCodes.h"

namespace CryptoNote {
namespace error {

HttpParserErrorCategory HttpParserErrorCategory::INSTANCE;

} //namespace error
} //namespace CryptoNote
