#!/bin/sh -e
. ./test_basic.sh
./test_configure.sh
