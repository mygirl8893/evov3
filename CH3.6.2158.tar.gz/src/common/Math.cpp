#include "Math.h"

namespace {
char suppressMSVCWarningLNK4221;
}
